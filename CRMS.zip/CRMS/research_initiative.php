<!-- Details of Sabbatical Leave Utilization for Research -->
<label for="sabbatical_details">Details of Sabbatical Leave Utilization for Research:</label>
<textarea id="sabbatical_details" name="sabbatical_details" required></textarea>

<!-- Research Awareness Initiatives (Description) -->
<label for="awareness_initiatives">Research Awareness Initiatives:</label>
<textarea id="awareness_initiatives" name="awareness_initiatives" required></textarea>

<!-- Budget Details for Research -->
<label for="research_budget">Budget Details for Research:</label>
<textarea id="research_budget" name="research_budget" required></textarea>

<!-- Financial Provisions for Student and Faculty Research -->
<label for="financial_provisions">Financial Provisions for Student and Faculty Research:</label>
<textarea id="financial_provisions" name="financial_provisions" required></textarea>

