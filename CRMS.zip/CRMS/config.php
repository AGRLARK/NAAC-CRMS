<?php

$conn = mysqli_connect('localhost','root','','crms_naac');


?>